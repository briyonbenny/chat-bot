# Invalid Question Test Documentation

## Overview
This document outlines the test cases and handling of invalid questions in the Weather-Aware Travel Chatbot system.

## Test Cases

### 1. Empty Input
```javascript
test('handle empty input', () => {
    const response = chatbot.handleInput('');
    expect(response).toBe('Please provide a valid question or location.');
});
```

### 2. Invalid Location
```javascript
test('handle invalid location', async () => {
    const response = await chatbot.handleInput('What should I wear in InvalidLocation?');
    expect(response).toContain('Location not found');
    expect(response).toContain('Please try again with a valid location.');
});
```

### 3. Malformed Questions
```javascript
test('handle malformed questions', () => {
    const malformedQuestions = [
        '?????',
        'wear what',
        'weather where',
        'help me',
        'I need clothes'
    ];

    malformedQuestions.forEach(question => {
        const response = chatbot.handleInput(question);
        expect(response).toContain('I didn\'t understand that question');
        expect(response).toContain('Please try asking about');
    });
});
```

### 4. Special Characters
```javascript
test('handle special characters', () => {
    const specialChars = [
        'What should I wear in London!@#$%',
        'Weather in Paris???',
        'Clothes for Tokyo...',
        'Help with NYC!!!'
    ];

    specialChars.forEach(input => {
        const response = chatbot.handleInput(input);
        expect(response).not.toContain('error');
        expect(response).toContain('valid');
    });
});
```

## Error Handling

### 1. Input Validation
```javascript
function validateInput(input) {
    if (!input || typeof input !== 'string') {
        throw new Error('Invalid input: Input must be a non-empty string');
    }
    
    if (input.trim().length === 0) {
        throw new Error('Invalid input: Input cannot be empty');
    }
    
    return input.trim();
}
```

### 2. Location Validation
```javascript
async function validateLocation(location) {
    try {
        const weatherData = await weatherAPI.getWeather(location);
        return weatherData;
    } catch (error) {
        if (error.status === 404) {
            throw new Error('Location not found');
        }
        throw error;
    }
}
```

### 3. Question Processing
```javascript
function processQuestion(question) {
    const keywords = ['wear', 'weather', 'clothes', 'temperature'];
    const hasKeyword = keywords.some(keyword => 
        question.toLowerCase().includes(keyword)
    );
    
    if (!hasKeyword) {
        throw new Error('Invalid question format');
    }
    
    return question;
}
```

## Response Templates

### 1. Error Messages
```javascript
const errorMessages = {
    emptyInput: 'Please provide a valid question or location.',
    invalidLocation: 'Location not found. Please try again with a valid location.',
    malformedQuestion: 'I didn\'t understand that question. Please try asking about:',
    invalidFormat: 'Please format your question properly. For example: "What should I wear in London?"',
    apiError: 'Sorry, I couldn\'t fetch the weather data. Please try again later.'
};
```

### 2. Help Messages
```javascript
const helpMessages = {
    suggestions: [
        'What should I wear in [location]?',
        'What\'s the weather like in [location]?',
        'What clothes do I need for [location]?',
        'Temperature in [location]?'
    ],
    examples: [
        'What should I wear in London?',
        'What\'s the weather like in Paris?',
        'What clothes do I need for Tokyo?'
    ]
};
```

## Test Implementation

### 1. Unit Tests
```javascript
describe('Invalid Input Handling', () => {
    test('empty input', () => {
        const response = handleInput('');
        expect(response).toBe(errorMessages.emptyInput);
    });

    test('null input', () => {
        const response = handleInput(null);
        expect(response).toBe(errorMessages.emptyInput);
    });

    test('undefined input', () => {
        const response = handleInput(undefined);
        expect(response).toBe(errorMessages.emptyInput);
    });
});
```

### 2. Integration Tests
```javascript
describe('Invalid Location Integration', () => {
    test('non-existent location', async () => {
        const response = await handleLocation('NonExistentLocation123');
        expect(response).toContain(errorMessages.invalidLocation);
    });

    test('malformed location', async () => {
        const response = await handleLocation('London!@#$');
        expect(response).toContain(errorMessages.invalidLocation);
    });
});
```

### 3. End-to-End Tests
```javascript
describe('Invalid Question Flow', () => {
    test('complete invalid question flow', async () => {
        // Start chat
        await startChat();
        
        // Send invalid question
        await sendMessage('?????');
        
        // Verify error response
        const response = await getLastResponse();
        expect(response).toContain(errorMessages.malformedQuestion);
        
        // Verify suggestions
        const suggestions = await getSuggestions();
        expect(suggestions).toContain(helpMessages.suggestions[0]);
    });
});
```

## Error Recovery

### 1. Graceful Degradation
```javascript
async function handleError(error) {
    if (error.type === 'location') {
        return {
            message: errorMessages.invalidLocation,
            suggestions: helpMessages.suggestions
        };
    }
    
    if (error.type === 'question') {
        return {
            message: errorMessages.malformedQuestion,
            examples: helpMessages.examples
        };
    }
    
    return {
        message: errorMessages.apiError,
        retry: true
    };
}
```

### 2. User Guidance
```javascript
function provideGuidance(error) {
    return {
        message: error.message,
        suggestions: helpMessages.suggestions,
        examples: helpMessages.examples,
        helpText: 'Try asking about weather or clothing recommendations for a specific location.'
    };
}
```

## Monitoring and Logging

### 1. Error Logging
```javascript
function logError(error, context) {
    console.error({
        timestamp: new Date().toISOString(),
        error: error.message,
        context,
        input: context.input,
        stack: error.stack
    });
}
```

### 2. Analytics
```javascript
function trackInvalidInput(input, type) {
    analytics.track('invalid_input', {
        input,
        type,
        timestamp: new Date().toISOString()
    });
}
```

## User Experience

### 1. Clear Feedback
- Immediate error messages
- Helpful suggestions
- Clear examples
- Easy recovery

### 2. Progressive Disclosure
- Basic error message
- Additional help if needed
- Examples on request
- Detailed guidance

### 3. Recovery Options
- Suggestion bubbles
- Help button
- Examples link
- Retry option

## Best Practices

### 1. Error Prevention
- Input validation
- Clear instructions
- Helpful suggestions
- Progressive guidance

### 2. Error Handling
- Graceful degradation
- Clear messages
- Recovery options
- Logging and monitoring

### 3. User Support
- Helpful responses
- Clear examples
- Easy navigation
- Quick recovery

## Testing Guidelines

### 1. Test Coverage
- All error cases
- Edge cases
- User scenarios
- Recovery paths

### 2. Test Quality
- Clear test cases
- Proper assertions
- Error scenarios
- Recovery verification

### 3. Documentation
- Test cases
- Error scenarios
- Recovery procedures
- User guidance

## Maintenance

### 1. Regular Updates
- Error messages
- Help text
- Examples
- Recovery options

### 2. Monitoring
- Error patterns
- User behavior
- Recovery success
- System performance

### 3. Improvements
- Error handling
- User experience
- Recovery options
- Documentation 