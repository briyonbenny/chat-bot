# REST API Documentation

## Overview
This document outlines the REST API endpoints used in the Weather-Aware Travel Chatbot system.

## Base URL
```
https://api.weatherapi.com/v1
```

## Authentication
All API requests require an API key to be included in the request header:
```
Authorization: Bearer YOUR_API_KEY
```

## Endpoints

### 1. Weather Data

#### Get Current Weather
```http
GET /current.json
```

**Parameters:**
- `q`: Location query (required)
- `aqi`: Air quality data (optional, default: no)

**Example Request:**
```http
GET /current.json?q=London&aqi=yes
```

**Response:**
```json
{
    "location": {
        "name": "London",
        "region": "City of London, Greater London",
        "country": "United Kingdom",
        "lat": 51.52,
        "lon": -0.11,
        "localtime": "2024-02-20 15:30"
    },
    "current": {
        "temp_c": 12.5,
        "condition": {
            "text": "Partly cloudy",
            "icon": "//cdn.weatherapi.com/weather/64x64/day/partly-cloudy.png"
        },
        "humidity": 76,
        "wind_kph": 11.2
    }
}
```

#### Get Forecast
```http
GET /forecast.json
```

**Parameters:**
- `q`: Location query (required)
- `days`: Number of days (optional, default: 3)
- `aqi`: Air quality data (optional, default: no)

**Example Request:**
```http
GET /forecast.json?q=London&days=3&aqi=yes
```

**Response:**
```json
{
    "location": {
        "name": "London",
        "region": "City of London, Greater London",
        "country": "United Kingdom",
        "lat": 51.52,
        "lon": -0.11,
        "localtime": "2024-02-20 15:30"
    },
    "current": {
        "temp_c": 12.5,
        "condition": {
            "text": "Partly cloudy",
            "icon": "//cdn.weatherapi.com/weather/64x64/day/partly-cloudy.png"
        },
        "humidity": 76,
        "wind_kph": 11.2
    },
    "forecast": {
        "forecastday": [
            {
                "date": "2024-02-20",
                "day": {
                    "maxtemp_c": 15.2,
                    "mintemp_c": 8.5,
                    "condition": {
                        "text": "Partly cloudy",
                        "icon": "//cdn.weatherapi.com/weather/64x64/day/partly-cloudy.png"
                    }
                }
            }
        ]
    }
}
```

### 2. Location Search

#### Search Location
```http
GET /search.json
```

**Parameters:**
- `q`: Search query (required)

**Example Request:**
```http
GET /search.json?q=London
```

**Response:**
```json
[
    {
        "id": 2803286,
        "name": "London",
        "region": "City of London, Greater London",
        "country": "United Kingdom",
        "lat": 51.52,
        "lon": -0.11,
        "url": "london-city-of-london-greater-london-united-kingdom"
    }
]
```

## Error Responses

### 400 Bad Request
```json
{
    "error": {
        "code": 1003,
        "message": "Parameter 'q' not provided."
    }
}
```

### 401 Unauthorized
```json
{
    "error": {
        "code": 1002,
        "message": "API key is invalid or not provided."
    }
}
```

### 404 Not Found
```json
{
    "error": {
        "code": 1006,
        "message": "No location found matching parameter 'q'"
    }
}
```

## Rate Limiting
- Free tier: 1,000,000 calls per month
- Basic tier: 5,000,000 calls per month
- Professional tier: 10,000,000 calls per month

## Best Practices

### 1. Error Handling
- Always check response status codes
- Implement retry logic for failed requests
- Handle rate limiting gracefully
- Log errors appropriately

### 2. Caching
- Cache weather data appropriately
- Implement cache invalidation
- Use appropriate cache headers
- Monitor cache hit rates

### 3. Performance
- Minimize API calls
- Use appropriate parameters
- Implement request batching
- Monitor response times

### 4. Security
- Secure API key storage
- Implement request validation
- Use HTTPS only
- Monitor for abuse

## Implementation Examples

### JavaScript
```javascript
class WeatherAPI {
    constructor(apiKey) {
        this.apiKey = apiKey;
        this.baseUrl = 'https://api.weatherapi.com/v1';
    }

    async getCurrentWeather(location) {
        const response = await fetch(
            `${this.baseUrl}/current.json?key=${this.apiKey}&q=${location}`
        );
        return await response.json();
    }

    async getForecast(location, days = 3) {
        const response = await fetch(
            `${this.baseUrl}/forecast.json?key=${this.apiKey}&q=${location}&days=${days}`
        );
        return await response.json();
    }
}
```

### Python
```python
import requests

class WeatherAPI:
    def __init__(self, api_key):
        self.api_key = api_key
        self.base_url = 'https://api.weatherapi.com/v1'

    def get_current_weather(self, location):
        response = requests.get(
            f'{self.base_url}/current.json',
            params={
                'key': self.api_key,
                'q': location
            }
        )
        return response.json()

    def get_forecast(self, location, days=3):
        response = requests.get(
            f'{self.base_url}/forecast.json',
            params={
                'key': self.api_key,
                'q': location,
                'days': days
            }
        )
        return response.json()
```

## Testing

### 1. API Testing
- Test all endpoints
- Verify error handling
- Check rate limiting
- Validate responses

### 2. Integration Testing
- Test with application
- Verify data flow
- Check error scenarios
- Monitor performance

### 3. Load Testing
- Test under load
- Verify stability
- Check response times
- Monitor resources

## Monitoring

### 1. Performance Monitoring
- Response times
- Error rates
- Usage patterns
- Resource usage

### 2. Error Monitoring
- Error types
- Error frequency
- Error patterns
- Resolution times

### 3. Usage Monitoring
- API calls
- Rate limiting
- Data usage
- Cost tracking

## Support

### 1. Documentation
- API documentation
- Integration guides
- Example code
- Troubleshooting

### 2. Contact
- Technical support
- API status
- Updates
- Feedback 