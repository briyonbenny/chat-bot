# Testing Documentation

## Overview 🧪

This document outlines the testing strategy and framework implementation for the Travel Weather Assistant Chatbot. The testing suite uses Jest for unit, integration, and end-to-end testing.

## Test Structure 📁

```
tests/
├── unit/
│   ├── weather-api.test.js
│   ├── clothing-recommender.test.js
│   ├── trip-manager.test.js
│   └── chat-logic.test.js
├── integration/
│   ├── api-integration.test.js
│   └── component-integration.test.js
└── e2e/
    └── user-flow.test.js
```

## Unit Tests

### Weather API Tests (Author: Sk. Navid Akram)
```javascript
describe('WeatherAPI', () => {
    test('should fetch weather data successfully', async () => {
        const api = new WeatherAPI();
        const data = await api.getWeather('London');
        expect(data).toHaveProperty('main.temp');
    });

    test('should handle invalid city names', async () => {
        const api = new WeatherAPI();
        await expect(api.getWeather('InvalidCity123')).rejects.toThrow();
    });

    test('should handle API errors', async () => {
        const api = new WeatherAPI();
        // Mock API failure
        await expect(api.getWeather('')).rejects.toThrow();
    });
});
```

### Trip Manager Tests (Author: Briyon Benny)
```javascript
describe('TripManager', () => {
    test('should add location to itinerary', () => {
        const manager = new TripManager();
        manager.addLocation('Paris', 'Monday');
        expect(manager.getItinerary()).toHaveLength(1);
    });

    test('should not exceed maximum locations', () => {
        const manager = new TripManager();
        for (let i = 0; i < 6; i++) {
            if (i < 5) {
                manager.addLocation(`City${i}`, 'Monday');
            } else {
                expect(() => manager.addLocation('ExtraCity', 'Monday')).toThrow();
            }
        }
    });
});
```

### Clothing Recommender Tests (Author: Joyal Joy)
```javascript
describe('ClothingRecommender', () => {
    test('should recommend warm clothing for cold weather', () => {
        const recommender = new ClothingRecommender();
        const weatherData = {
            main: { temp: 5 },
            weather: [{ main: 'Clear' }]
        };
        const recommendations = recommender.getRecommendation(weatherData);
        expect(recommendations.recommendations).toContain('Winter coat');
    });

    test('should recommend light clothing for warm weather', () => {
        const recommender = new ClothingRecommender();
        const weatherData = {
            main: { temp: 25 },
            weather: [{ main: 'Clear' }]
        };
        const recommendations = recommender.getRecommendation(weatherData);
        expect(recommendations.recommendations).toContain('Light, breathable clothing');
    });
});
```

## Integration Tests

### API Integration Tests (Author: Sk. Navid Akram)
```javascript
describe('Weather API Integration', () => {
    test('should integrate with OpenWeatherMap API', async () => {
        const api = new WeatherAPI();
        const chatbot = new ChatBot();
        const result = await chatbot.processMessage('London on Monday');
        expect(result).toHaveProperty('text');
        expect(result.text).toContain('London');
    });
});
```

### Component Integration Tests
```javascript
describe('Component Integration', () => {
    test('should process full trip planning flow', async () => {
        const chatbot = new ChatBot();
        
        // Start conversation
        let response = await chatbot.processMessage('');
        expect(response.text).toContain('Welcome');
        
        // Add location
        response = await chatbot.processMessage('London on Monday');
        expect(response.text).toContain('Great');
        
        // Complete trip
        for (let i = 0; i < 4; i++) {
            response = await chatbot.processMessage(`City${i} on Tuesday`);
        }
        expect(response.text).toContain('recommendations');
    });
});
```

## End-to-End Tests

### User Flow Tests
```javascript
describe('User Flow', () => {
    test('should complete full user journey', async () => {
        const chatbot = new ChatBot();
        const flow = [
            '',  // Initial greeting
            'London on Monday',
            'Paris on Tuesday',
            'Berlin on Wednesday',
            'Rome on Thursday',
            'Madrid on Friday'
        ];

        for (const message of flow) {
            const response = await chatbot.processMessage(message);
            expect(response).toBeDefined();
            expect(response.text.length).toBeGreaterThan(0);
        }
    });
});
```

## Test Coverage Requirements

1. **Unit Tests**
   - Minimum 80% coverage for each component
   - All public methods tested
   - Edge cases covered
   - Error scenarios tested

2. **Integration Tests**
   - API integration verified
   - Component interaction tested
   - State management verified
   - Error handling tested

3. **End-to-End Tests**
   - Complete user flows tested
   - UI interaction verified
   - Data persistence checked
   - Error recovery tested

## Running Tests

```bash
# Install dependencies
npm install

# Run all tests
npm test

# Run specific test file
npm test weather-api.test.js

# Generate coverage report
npm run test:coverage
```

## Test Reports

### Coverage Report Example
```
--------------------------|---------|----------|---------|---------|
File                      | % Stmts | % Branch | % Funcs | % Lines |
--------------------------|---------|----------|---------|---------|
All files                 |   85.71 |    76.92 |   88.89 |   85.71 |
 weather-api.js           |   90.91 |    83.33 |   85.71 |   90.91 |
 clothing-recommender.js  |   84.62 |    70.00 |   90.91 |   84.62 |
 trip-manager.js         |   81.82 |    75.00 |   90.00 |   81.82 |
 chat-logic.js           |   85.48 |    79.37 |   88.89 |   85.48 |
--------------------------|---------|----------|---------|---------|
```

## Continuous Integration

1. **GitHub Actions Workflow**
```yaml
name: Tests
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - uses: actions/setup-node@v2
      - run: npm install
      - run: npm test
```

## Test Maintenance

1. **Regular Updates**
   - Update tests with new features
   - Maintain test data
   - Review coverage reports
   - Update documentation

2. **Best Practices**
   - Keep tests focused
   - Use meaningful descriptions
   - Maintain test independence
   - Follow naming conventions

## Contact

For questions about testing:
- Sk. Navid Akram (Lead Developer) - navid.akram@example.com 