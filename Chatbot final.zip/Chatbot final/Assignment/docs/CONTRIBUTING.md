# Contributing Guidelines

## Team Members and Contributions

### Sk. Navid Akram (3144286) - Lead Developer 👨‍💻

#### Major Contributions:
1. **Weather API Integration**
   - Implemented the OpenWeatherMap API integration
   - Developed error handling for API calls
   - Created weather data parsing functionality
   - Implemented city validation system
   - Documentation of API integration

2. **Core Architecture**
   - Designed the overall system architecture
   - Created the modular component structure
   - Implemented the state management system
   - Developed the main chat logic flow
   - Code review and quality assurance

3. **Testing Framework**
   - Set up Jest testing environment
   - Created unit tests for Weather API
   - Implemented integration tests
   - Developed testing documentation
   - Maintained test coverage reports

4. **Project Management**
   - Repository setup and maintenance
   - Code review process implementation
   - Team coordination and task assignment
   - Documentation structure
   - Milestone tracking

#### Commits:
- Initial project setup and structure
- Weather API integration implementation
- Testing framework setup
- Core chat logic development
- Documentation updates
- Code review and fixes
- Performance optimizations

### Joyal Joy (3147134) - Frontend Developer 🎨

#### Contributions:
1. **UI Development**
   - HTML/CSS implementation
   - Responsive design
   - Chat interface styling
   - Suggestion bubbles implementation

2. **User Experience**
   - Input handling
   - Error message display
   - Loading states
   - Accessibility features

#### Commits:
- UI implementation
- Style updates
- Accessibility improvements
- Frontend bug fixes

### Briyon Benny (3144036) - Backend Developer 🔧

#### Contributions:
1. **Data Management**
   - Trip manager implementation
   - Clothing recommender logic
   - Data persistence
   - Error handling

2. **Integration**
   - Component integration
   - Backend testing
   - Performance optimization

#### Commits:
- Backend logic implementation
- Data structure setup
- Integration testing
- Performance improvements

## Development Workflow

1. **Branch Naming Convention**
```
feature/feature-name
bugfix/bug-description
docs/documentation-update
```

2. **Commit Message Format**
```
type(scope): description

[optional body]

[optional footer]
```

3. **Pull Request Process**
- Create feature branch
- Implement changes
- Write/update tests
- Update documentation
- Create pull request
- Code review
- Merge to main

## Code Review Process

1. **Review Checklist**
- Code follows style guide
- Tests are included
- Documentation is updated
- No unnecessary changes
- Performance considerations
- Security considerations

2. **Review Comments**
- Be constructive
- Reference specific lines
- Suggest improvements
- Explain reasoning

## Testing Requirements

1. **Unit Tests**
- All new features must have unit tests
- Minimum 80% coverage
- Tests must pass before merge

2. **Integration Tests**
- Test component interactions
- API integration tests
- UI integration tests

## Documentation

1. **Code Documentation**
- JSDoc comments for functions
- Inline comments for complex logic
- README updates for new features
- API documentation updates

2. **Commit History**
- Clear commit messages
- Logical commit grouping
- Reference issues/tickets

## Getting Started

1. **Setup Development Environment**
```bash
# Clone repository
git clone https://github.com/your-username/chatbot_weather

# Install dependencies
npm install

# Run tests
npm test

# Start development server
npm start
```

2. **Making Changes**
```bash
# Create feature branch
git checkout -b feature/your-feature

# Make changes
# Run tests
npm test

# Commit changes
git commit -m "feat(scope): description"

# Push changes
git push origin feature/your-feature
```

## Code Style Guide

1. **JavaScript**
- Use ES6+ features
- Follow airbnb style guide
- Use meaningful variable names
- Keep functions small and focused

2. **HTML/CSS**
- Use semantic HTML
- Follow BEM naming convention
- Maintain responsive design
- Ensure accessibility

## Contact

For any questions or concerns, please contact:
- Sk. Navid Akram (Lead Developer) - navid.akram@example.com 