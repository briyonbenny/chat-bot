class ChatBot {
    constructor() {
        this.weatherAPI = new WeatherAPI();
        this.clothingRecommender = new ClothingRecommender();
        this.tripManager = new TripManager();
        this.state = 'GREETING';
        this.currentLocationIndex = 0;
        
        // Pre-defined cities for easy selection
        this.popularCities = [
            "New York", "London", "Paris", "Tokyo", "Sydney",
            "Dubai", "Singapore", "Mumbai", "Toronto", "Berlin"
        ];

        // Common follow-up suggestions
        this.commonSuggestions = {
            yes: ["Yes, that sounds good!", "Yes, please", "Sure!"],
            no: ["No, thanks", "Maybe later", "Not now"],
            help: ["Can you explain more?", "Show me examples", "I need help"]
        };
    }

    async processMessage(message) {
        let response;
        
        switch (this.state) {
            case 'GREETING':
                this.state = 'START_PLANNING';
                return {
                    text: "👋 Hi! I'm your Travel Weather Assistant. I'll help you plan what to wear for your trip.\n\nWould you like to start planning your trip?",
                    suggestions: [...this.commonSuggestions.yes.slice(0, 1), "Tell me more"],
                    followUp: this.commonSuggestions.help
                };

            case 'START_PLANNING':
                if (message.toLowerCase().includes('tell me more')) {
                    return {
                        text: "I can help you plan clothing for a trip to 5 different locations. I'll check the weather for each place and suggest what to pack. Ready to start?",
                        suggestions: [...this.commonSuggestions.yes.slice(0, 2), ...this.commonSuggestions.no.slice(0, 1)],
                        followUp: ["Show me an example", "How does it work?"]
                    };
                } else if (message.toLowerCase().includes('how does it work')) {
                    return {
                        text: "It's simple! Just tell me the cities you'll visit and when. I'll check the weather and suggest what clothes to pack. Ready to try?",
                        suggestions: this.commonSuggestions.yes.slice(0, 2),
                        followUp: ["Show me an example"]
                    };
                } else if (message.toLowerCase().includes('show me an example')) {
                    return {
                        text: "Here's an example:\nYou: 'Paris on Monday'\nMe: I'll check Paris weather and suggest clothes!\n\nWould you like to start with your first destination?",
                        suggestions: ["Yes, let's start!", ...this.getRandomCities(2).map(city => `${city} on Monday`)],
                        followUp: this.commonSuggestions.help
                    };
                }
                this.state = 'COLLECTING_LOCATIONS';
                this.currentLocationIndex = 0;
                return {
                    text: "Great! Let's plan your first destination. You can either:\n1. Type a city name and day (e.g., 'Paris on Monday')\n2. Or click one of the suggested cities below:",
                    suggestions: this.getRandomCities(3).map(city => `${city} on Monday`),
                    followUp: ["Show me more cities", "How to format?"]
                };

            case 'COLLECTING_LOCATIONS':
                if (message.toLowerCase().includes('show me more cities')) {
                    return {
                        text: "Here are more city suggestions for your trip:",
                        suggestions: this.getRandomCities(4).map(city => `${city} on ${this.getDayForIndex(this.currentLocationIndex)}`),
                        followUp: ["Show me more cities", "How to format?"]
                    };
                } else if (message.toLowerCase().includes('how to format')) {
                    return {
                        text: "Just type or select a city followed by 'on' and the day, like this: 'Paris on Monday'",
                        suggestions: this.getRandomCities(3).map(city => `${city} on ${this.getDayForIndex(this.currentLocationIndex)}`),
                        followUp: ["Show me more cities"]
                    };
                }

                try {
                    const { city, date } = this.parseLocationAndDate(message);
                    
                    try {
                        await this.weatherAPI.getWeather(city);
                    } catch (error) {
                        return {
                            text: `I couldn't find weather data for "${city}". Please try another city name.`,
                            suggestions: this.getRandomCities(3).map(city => `${city} on ${this.getDayForIndex(this.currentLocationIndex)}`),
                            followUp: ["Show me more cities", "How to format?"]
                        };
                    }

                    this.tripManager.addLocation(city, date);
                    this.currentLocationIndex++;
                    
                    if (this.tripManager.isComplete()) {
                        this.state = 'CONFIRMING_ITINERARY';
                        const itinerary = this.tripManager.getItinerary();
                        let confirmText = "Perfect! Here's your trip itinerary:\n\n";
                        itinerary.forEach((loc, idx) => {
                            confirmText += `${idx + 1}. ${loc.city} on ${loc.date}\n`;
                        });
                        confirmText += "\nWould you like me to get weather and clothing recommendations for these locations?";
                        return {
                            text: confirmText,
                            suggestions: ["Yes, get recommendations", "Start over"],
                            followUp: ["Edit itinerary", "Save for later"]
                        };
                    }

                    const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
                    return {
                        text: `Great! ${city} has been added for ${date}.\n\nNow, where's your ${this.getNumberWord(this.currentLocationIndex + 1)} destination?`,
                        suggestions: this.getRandomCities(3).map(city => `${city} on ${daysOfWeek[this.currentLocationIndex]}`),
                        followUp: ["Show me more cities", "Start over"]
                    };

                } catch (error) {
                    return {
                        text: "I didn't quite get that. Please tell me the city and day like this: 'Paris on Monday' or click one of the suggestions below.",
                        suggestions: this.getRandomCities(3).map(city => `${city} on ${this.getDayForIndex(this.currentLocationIndex)}`),
                        followUp: ["Show me more cities", "How to format?"]
                    };
                }

            case 'CONFIRMING_ITINERARY':
                if (message.toLowerCase().includes('start over')) {
                    this.state = 'START_PLANNING';
                    this.tripManager.clearItinerary();
                    this.currentLocationIndex = 0;
                    return {
                        text: "Let's start fresh! Where's your first destination?",
                        suggestions: this.getRandomCities(3).map(city => `${city} on Monday`),
                        followUp: ["Show me more cities", "How to format?"]
                    };
                }
                this.state = 'PROVIDING_RECOMMENDATIONS';
                return await this.generateRecommendations();

            case 'PROVIDING_RECOMMENDATIONS':
                this.state = 'START_PLANNING';
                this.tripManager.clearItinerary();
                return {
                    text: "Would you like to plan another trip?",
                    suggestions: ["Yes, plan new trip", ...this.commonSuggestions.no.slice(0, 1)],
                    followUp: ["Show me what else you can do", "Give feedback"]
                };

            default:
                return {
                    text: "Let's start over. Would you like to plan a trip?",
                    suggestions: ["Yes, let's start!", ...this.commonSuggestions.no.slice(0, 1)],
                    followUp: this.commonSuggestions.help
                };
        }
    }

    getRandomCities(count) {
        const shuffled = [...this.popularCities].sort(() => 0.5 - Math.random());
        return shuffled.slice(0, count);
    }

    getDayForIndex(index) {
        const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
        return days[index] || days[0];
    }

    parseLocationAndDate(message) {
        const match = message.match(/(.+) on (.+)/i);
        if (!match) {
            throw new Error('Invalid format');
        }
        return {
            city: match[1].trim(),
            date: match[2].trim()
        };
    }

    getNumberWord(num) {
        const words = ['first', 'second', 'third', 'fourth', 'fifth'];
        return words[num - 1] || num.toString();
    }

    async generateRecommendations() {
        let response = "📋 Here are your personalized clothing recommendations:\n\n";
        
        try {
            for (let i = 0; i < this.tripManager.getItinerary().length; i++) {
                const location = this.tripManager.getItinerary()[i];
                const weatherData = await this.tripManager.updateWeatherForLocation(i, this.weatherAPI);
                const recommendation = this.clothingRecommender.getRecommendation(weatherData);
                
                response += `🌍 ${location.city} on ${location.date}:\n`;
                response += `🌡️ Temperature: ${recommendation.temperature}°C\n`;
                response += `☁️ Weather: ${weatherData.weather[0].description}\n`;
                response += "👔 Recommended clothing:\n";
                recommendation.recommendations.forEach(item => {
                    response += `   • ${item}\n`;
                });
                response += "\n";
            }

            response += "Would you like to plan another trip?";
        } catch (error) {
            response = "Sorry, I had trouble getting weather data. Would you like to try again?";
        }

        return {
            text: response,
            suggestions: ["Plan another trip", "No, thank you"],
            followUp: ["Save recommendations", "Share itinerary"]
        };
    }
}

// Initialize the chatbot when the page loads
document.addEventListener('DOMContentLoaded', () => {
    const chatbot = new ChatBot();
    const messagesContainer = document.getElementById('messages');
    const userInput = document.getElementById('user-input');
    const sendButton = document.getElementById('send-button');
    const suggestionBubbles = document.createElement('div');
    suggestionBubbles.className = 'suggestion-bubbles';

    function addMessage(text, isUser = false) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${isUser ? 'user-message' : 'bot-message'}`;
        messageDiv.textContent = text;
        messagesContainer.appendChild(messageDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    function updateSuggestions(suggestions, followUp = []) {
        const primaryContainer = document.querySelector('.primary-suggestions');
        const followUpContainer = document.querySelector('.followup-suggestions');
        
        // Clear existing suggestions
        primaryContainer.innerHTML = '';
        followUpContainer.innerHTML = '';
        
        // Add primary suggestions
        if (suggestions && suggestions.length) {
            suggestions.forEach(suggestion => {
                const bubble = document.createElement('button');
                bubble.className = 'suggestion-bubble primary';
                bubble.textContent = suggestion;
                bubble.onclick = () => {
                    userInput.value = suggestion;
                    sendMessage();
                };
                primaryContainer.appendChild(bubble);
            });
        }
        
        // Add follow-up suggestions
        if (followUp && followUp.length) {
            followUp.forEach(suggestion => {
                const bubble = document.createElement('button');
                bubble.className = 'suggestion-bubble followup';
                bubble.textContent = suggestion;
                bubble.onclick = () => {
                    userInput.value = suggestion;
                    sendMessage();
                };
                followUpContainer.appendChild(bubble);
            });
        }
    }

    async function sendMessage() {
        const message = userInput.value.trim();
        if (!message) return;

        addMessage(message, true);
        userInput.value = '';

        const response = await chatbot.processMessage(message);
        addMessage(response.text);
        updateSuggestions(response.suggestions, response.followUp);
    }

    userInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });

    sendButton.addEventListener('click', sendMessage);

    // Start the conversation
    chatbot.processMessage('').then(response => {
        addMessage(response.text);
        updateSuggestions(response.suggestions, response.followUp);
    });
});

// Export the ChatBot class
window.ChatBot = ChatBot; 