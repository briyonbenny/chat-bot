const WEATHER_API_KEY = '97ba6540cb01dce1900aec4c6a75b242';

class WeatherAPI {
    constructor() {
        this.baseUrl = 'https://api.openweathermap.org/data/2.5/weather';
    }

    async getWeather(city) {
        try {
            const response = await fetch(`${this.baseUrl}?q=${city}&appid=${WEATHER_API_KEY}&units=metric`);
            if (!response.ok) {
                throw new Error('Weather data not available');
            }
            return await response.json();
        } catch (error) {
            console.error('Error fetching weather:', error);
            throw error;
        }
    }
}

// Export the WeatherAPI class
window.WeatherAPI = WeatherAPI; 