class TripManager {
    constructor() {
        this.itinerary = [];
        this.maxLocations = 5;
        this.maxDays = 3;
    }

    addLocation(city, date) {
        if (this.itinerary.length >= this.maxLocations) {
            throw new Error(`Cannot add more than ${this.maxLocations} locations`);
        }

        this.itinerary.push({
            city: city,
            date: date,
            weather: null,
            recommendations: null
        });
    }

    async updateWeatherForLocation(index, weatherAPI) {
        if (index < 0 || index >= this.itinerary.length) {
            throw new Error('Invalid location index');
        }

        const location = this.itinerary[index];
        const weatherData = await weatherAPI.getWeather(location.city);
        this.itinerary[index].weather = weatherData;
        
        return weatherData;
    }

    getItinerary() {
        return this.itinerary;
    }

    clearItinerary() {
        this.itinerary = [];
    }

    isComplete() {
        return this.itinerary.length === this.maxLocations;
    }
}

// Export the TripManager class
window.TripManager = TripManager; 