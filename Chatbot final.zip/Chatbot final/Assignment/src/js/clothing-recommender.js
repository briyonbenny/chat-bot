class ClothingRecommender {
    constructor() {
        this.recommendations = {
            cold: {
                temp: temp => temp < 10,
                items: [
                    'Heavy winter coat',
                    'Thermal underwear',
                    'Warm sweater',
                    'Winter boots',
                    'Gloves',
                    'Scarf',
                    'Winter hat'
                ]
            },
            cool: {
                temp: temp => temp >= 10 && temp < 20,
                items: [
                    'Light jacket or coat',
                    'Long-sleeve shirts',
                    'Light sweater',
                    'Closed-toe shoes',
                    'Light scarf'
                ]
            },
            mild: {
                temp: temp => temp >= 20 && temp < 25,
                items: [
                    'Light layers',
                    'Long or short-sleeve shirts',
                    'Light pants or long shorts',
                    'Comfortable walking shoes'
                ]
            },
            warm: {
                temp: temp => temp >= 25,
                items: [
                    'Light, breathable clothing',
                    'Short-sleeve shirts',
                    'Shorts',
                    'Sandals or light shoes',
                    'Sun hat',
                    'Sunglasses'
                ]
            }
        };
    }

    getRecommendation(weatherData) {
        const temp = weatherData.main.temp;
        const weather = weatherData.weather[0].main.toLowerCase();
        
        let clothing = [];
        
        // Get base clothing recommendations based on temperature
        for (const [_, category] of Object.entries(this.recommendations)) {
            if (category.temp(temp)) {
                clothing = [...category.items];
                break;
            }
        }
        
        // Add weather-specific items
        if (weather.includes('rain')) {
            clothing.push('Raincoat or umbrella', 'Waterproof shoes');
        } else if (weather.includes('snow')) {
            clothing.push('Waterproof winter boots', 'Snow-appropriate outerwear');
        }
        
        return {
            temperature: temp,
            weather: weather,
            recommendations: clothing
        };
    }
}

// Export the ClothingRecommender class
window.ClothingRecommender = ClothingRecommender; 