# Git Workflow Guidelines for 3-Member Team

## Team Structure

### Roles
1. **Team Lead**
   - Manages main branches
   - Reviews and merges pull requests
   - Maintains release schedule
   - Coordinates team efforts

2. **Core Developer**
   - Focuses on core functionality
   - Works on weather API and business logic
   - Reviews UI changes

3. **UI Developer**
   - Handles user interface components
   - Manages styling and layout
   - Reviews core functionality changes

## Branch Strategy

### Main Branches
- `main`: Production-ready code
- `develop`: Integration branch for features

### Feature Branches
- Format: `feature/<developer-initials>/<feature-name>`
- Examples:
  - `feature/tl/weather-api`
  - `feature/cd/clothing-recommender`
  - `feature/ud/chat-interface`

### Hotfix Branches
- Format: `hotfix/<issue-description>`
- Created from `main`
- Merged back to both `main` and `develop`

## Daily Workflow

### Starting Work
1. Update local repository:
   ```bash
   git checkout develop
   git pull origin develop
   ```

2. Create feature branch:
   ```bash
   git checkout -b feature/<your-initials>/<feature-name>
   ```

### During Development
1. Make small, focused commits:
   ```bash
   git add <changed-files>
   git commit -m "type(scope): description"
   ```

2. Keep branch updated:
   ```bash
   git checkout develop
   git pull origin develop
   git checkout feature/<your-initials>/<feature-name>
   git merge develop
   ```

### Completing Work
1. Push changes:
   ```bash
   git push origin feature/<your-initials>/<feature-name>
   ```

2. Create Pull Request:
   - Target branch: `develop`
   - Add description of changes
   - Request review from team members

## Code Review Process

### For Team Lead
1. Review all pull requests
2. Check for:
   - Code quality
   - Test coverage
   - Documentation updates
   - Commit message format
3. Merge after approval

### For Core Developer
1. Review UI-related changes
2. Verify API integration
3. Check performance impact

### For UI Developer
1. Review core functionality changes
2. Verify UI consistency
3. Check responsive design

## Commit Guidelines

### Message Format
```
<type>(<scope>): <subject>

[optional body]

[optional footer]
```

### Types
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation
- `style`: Formatting
- `refactor`: Code restructuring
- `test`: Test updates
- `chore`: Maintenance

### Examples
```
feat(core): Add temperature conversion
fix(ui): Fix chat bubble alignment
docs(api): Update weather API docs
```

## Conflict Resolution

### When Conflicts Occur
1. Update your branch with latest develop:
   ```bash
   git checkout develop
   git pull origin develop
   git checkout feature/<your-branch>
   git merge develop
   ```

2. Resolve conflicts in files
3. Commit resolved changes:
   ```bash
   git add <resolved-files>
   git commit -m "fix(merge): Resolve merge conflicts"
   ```

## Release Process

### Preparing Release
1. Team Lead creates release branch:
   ```bash
   git checkout -b release/v1.0.0 develop
   ```

2. Team reviews and tests
3. Fix any issues in release branch
4. Merge to main and develop:
   ```bash
   git checkout main
   git merge release/v1.0.0
   git tag -a v1.0.0 -m "Release v1.0.0"
   git checkout develop
   git merge release/v1.0.0
   git branch -d release/v1.0.0
   ```

## Best Practices

### For All Team Members
1. Keep commits atomic and focused
2. Write clear commit messages
3. Update documentation as needed
4. Test before pushing
5. Review others' code thoroughly

### Communication
1. Use pull request comments for discussions
2. Tag team members when needed
3. Update project board/tasks
4. Regular team sync-ups

### Emergency Fixes
1. Create hotfix branch from main
2. Fix the issue
3. Test thoroughly
4. Merge to main and develop
5. Delete hotfix branch

## Tools and Resources

### Git Commands Reference
```bash
# View branch status
git status

# View commit history
git log --oneline

# Stash changes
git stash

# Apply stashed changes
git stash pop

# View remote branches
git branch -r
```

### Useful Git Aliases
```bash
# Add to .gitconfig
[alias]
    st = status
    co = checkout
    br = branch
    ci = commit
    lg = log --graph --oneline --all
```

## Troubleshooting

### Common Issues
1. **Merge Conflicts**
   - Use `git status` to identify conflicts
   - Resolve in code editor
   - Commit resolved changes

2. **Lost Changes**
   - Check `git reflog`
   - Use `git stash` for temporary storage
   - Create backup branch before major changes

3. **Wrong Branch**
   - Stash changes: `git stash`
   - Switch branch: `git checkout <branch>`
   - Apply changes: `git stash pop` 