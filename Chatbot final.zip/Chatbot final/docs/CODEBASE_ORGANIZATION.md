# Codebase Organization and Commit Guidelines

## Directory Structure

The codebase is organized into the following structure:

```
src/
├── core/           # Core business logic and data processing
│   ├── weather-api.js         # Weather API integration
│   ├── clothing-recommender.js # Clothing recommendation logic
│   └── trip-manager.js        # Trip management functionality
│
├── ui/            # User interface and presentation layer
│   ├── index.html  # Main HTML entry point
│   ├── ui.js       # UI components and styling
│   ├── chat.js     # Chat interface logic
│   └── weather.js  # Weather display components
│
└── docs/          # Documentation
    ├── TEACHER_GUIDE.md
    ├── TESTING.md
    └── ...
```

## Core Components

The `src/core` directory contains the essential business logic and data processing components:

- `weather-api.js`: Handles integration with external weather APIs and data processing
- `clothing-recommender.js`: Contains algorithms for recommending appropriate clothing based on weather conditions
- `trip-manager.js`: Manages trip-related functionality and data

## UI Components

The `src/ui` directory contains all user interface related code:

- `index.html`: The main entry point of the application
- `ui.js`: General UI components and styling utilities
- `chat.js`: Chat interface implementation
- `weather.js`: Weather information display components

## Commit Guidelines

### Commit Message Format

```
<type>(<scope>): <subject>

[optional body]

[optional footer]
```

### Types

- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation changes
- `style`: Code style changes (formatting, missing semi colons, etc)
- `refactor`: Code refactoring
- `test`: Adding missing tests
- `chore`: Changes to the build process or auxiliary tools

### Scopes

- `core`: Changes to core business logic
- `ui`: Changes to user interface
- `docs`: Changes to documentation
- `test`: Changes to test files
- `organization`: Changes to project structure

### Examples

```
feat(core): Add temperature unit conversion
fix(ui): Resolve chat message alignment
docs(api): Update weather API documentation
refactor(core): Optimize clothing recommendation algorithm
```

## Development Workflow

1. Create a feature branch from `develop`
2. Make changes following the organization structure
3. Commit changes using the commit message format
4. Create a pull request to merge into `develop`
5. After review, merge into `develop`
6. Periodically merge `develop` into `main` for releases

## Code Review Guidelines

1. Check if the changes are in the appropriate directory
2. Verify commit messages follow the guidelines
3. Ensure documentation is updated if needed
4. Review for code quality and test coverage
5. Verify UI changes maintain consistency 