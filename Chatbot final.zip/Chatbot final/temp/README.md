# Travel Weather Assistant Chatbot 🌦️

A smart chatbot that helps users plan their clothing for multi-city trips based on weather conditions.

## Features 🌟

- Plan trips to 5 locations over 3 days
- Real-time weather data integration
- Smart clothing recommendations
- Interactive chat interface
- Suggestion bubbles for easy interaction
- Error handling and input validation

## Tech Stack 💻

- HTML5/CSS3 for the user interface
- Vanilla JavaScript for functionality
- OpenWeatherMap API for weather data
- Jest for testing framework

## Project Structure 📁

```
chatbot_weather-main/
├── src/
│   ├── js/
│   │   ├── weather-api.js      # Weather API integration
│   │   ├── clothing-recommender.js  # Clothing recommendation logic
│   │   ├── trip-manager.js     # Trip itinerary management
│   │   └── chat-logic.js       # Main chatbot logic
│   └── index.html              # Main application interface
├── tests/
│   ├── weather-api.test.js
│   ├── clothing-recommender.test.js
│   ├── trip-manager.test.js
│   └── chat-logic.test.js
├── docs/
│   ├── ARCHITECTURE.md         # System architecture documentation
│   ├── CONTRIBUTING.md         # Contribution guidelines
│   ├── FLOWCHART.md           # Application flow documentation
│   └── TESTING.md             # Testing documentation
└── README.md                   # Project overview
```

## Team Members 👥

- Sk. Navid Akram (3144286) - Lead Developer
- Joyal Joy (3147134) - Frontend Developer
- Briyon Benny (3144036) - Backend Developer

## Setup Instructions 🚀

1. Clone the repository:
```bash
git clone https://github.com/your-username/chatbot_weather
```

2. Navigate to the project directory:
```bash
cd chatbot_weather
```

3. Open `src/index.html` in a web browser or set up a local server:
```bash
python -m http.server 8000
```

4. Visit `http://localhost:8000/src/` in your browser

## API Key Setup 🔑

The chatbot uses OpenWeatherMap API. To set up your API key:

1. Sign up at [OpenWeatherMap](https://openweathermap.org/api)
2. Get your API key
3. Replace the API key in `src/js/weather-api.js`:
```javascript
const WEATHER_API_KEY = 'your-api-key';
```

## Documentation 📚

- [Architecture Documentation](docs/ARCHITECTURE.md)
- [Contributing Guidelines](docs/CONTRIBUTING.md)
- [Application Flow](docs/FLOWCHART.md)
- [Testing Documentation](docs/TESTING.md)

## License 📄

MIT License - see LICENSE file for details
